-- AlterTable
ALTER TABLE "user" ADD COLUMN     "timezone" TEXT DEFAULT 'UTC+3';
