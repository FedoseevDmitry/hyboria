<template>
  <NuxtLayout />
</template>

<script setup>
</script>
