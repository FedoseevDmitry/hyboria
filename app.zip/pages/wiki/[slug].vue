<template>
  <div
    class="max-w-3xl mx-auto p-6 transition-colors"
    :class="colorMode.value === 'dark' ? 'text-white' : 'text-black'"
  >
    <h1 class="text-2xl font-bold mb-4">
      {{ article.title }}
    </h1>

    <div class="whitespace-pre-line text-gray-700 dark:text-gray-300">
      {{ article.content }}
    </div>
  </div>
</template>

<script setup>
const route = useRoute()
const { data: article } = await useFetch(`/api/wiki/${route.params.slug}`)

const colorMode = useColorMode()
</script>
