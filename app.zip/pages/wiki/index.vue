<template>
  <div
    class="max-w-4xl mx-auto p-6 transition-colors"
    :class="colorMode.value === 'dark' ? 'text-white' : 'text-black'"
  >
    <h1 class="text-3xl font-bold mb-6">
      WIKI
    </h1>

    <div v-if="!articles?.length" class="text-gray-500 dark:text-gray-400">
      Пока нет статей
    </div>

    <ul class="space-y-2">
      <li v-for="a in articles" :key="a.id">
        <NuxtLink
          :to="`/wiki/${a.slug}`"
          class="hover:underline text-blue-600 dark:text-blue-400"
        >
          {{ a.title }}
        </NuxtLink>
      </li>
    </ul>
  </div>
</template>

<script setup>
const { data: articles } = await useFetch('/api/wiki')
const colorMode = useColorMode()
</script>
