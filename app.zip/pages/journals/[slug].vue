<template>
  <div class="max-w-4xl mx-auto p-6">
    <h1 class="text-3xl font-bold mb-4">{{ journal?.character }}</h1>

    <p v-if="!journal?.posts?.length" class="text-gray-500 dark:text-gray-400">Пока нет записей</p>

    <div class="space-y-4" v-else>
      <div
        v-for="post in journal.posts"
        :key="post.id"
        class="bg-white dark:bg-gray-800 p-4 rounded-lg shadow"
      >
        <NuxtLink
          :to="`/journals/${journal.slug}/posts/${post.slug}`"
          class="text-xl font-semibold text-blue-600 dark:text-blue-400 hover:underline"
        >
          {{ post.title }}
        </NuxtLink>
        <p class="text-sm text-gray-600 dark:text-gray-300 mt-1">
          {{ post.content.slice(0, 150) }}...
        </p>
      </div>
    </div>
  </div>
</template>

<script setup>
const route = useRoute()
const { data: journal } = await useFetch(`/api/journals/${route.params.slug}`)
</script>
