<template>
  <div class="max-w-3xl mx-auto p-6">
    <div v-if="!news">
      <p class="text-gray-500 dark:text-gray-400">Новость не найдена.</p>
    </div>
    <div v-else>
      <img v-if="news.image" :src="news.image" class="mb-4 rounded" />
      <h1 class="text-3xl font-bold mb-4">{{ news.title }}</h1>
      <p class="text-gray-700 dark:text-gray-300 whitespace-pre-line">{{ news.content }}</p>
    </div>
  </div>
</template>

<script setup>
const route = useRoute()

// Используем useFetch и сохраняем результат в `response`
const response = await useFetch('/api/news')

// Проверяем: это массив?
const newsArray = computed(() =>
  Array.isArray(response.data.value) ? response.data.value : []
)

// Ищем новость по слагу
const news = computed(() =>
  newsArray.value.find((n) => n.slug === route.params.slug)
)
</script>
