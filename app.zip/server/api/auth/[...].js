import { NuxtAuthHandler } from '#auth'
import authConfig from '~/auth.config.js'

export default NuxtAuthHandler(authConfig)
