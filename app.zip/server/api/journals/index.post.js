import { getServerSession } from '#auth'
import { prisma } from '#nuxt-prisma'

export default defineEventHandler(async (event) => {
  const session = await getServerSession(event)

  if (!session?.user?.email) {
    return sendError(event, createError({ statusCode: 401, statusMessage: 'Не авторизован' }))
  }

  const body = await readBody(event)

  const { character, content, image } = body

  if (!character || !content) {
    return sendError(event, createError({ statusCode: 400, statusMessage: 'Имя персонажа и текст обязательны' }))
  }

  const user = await prisma.user.findUnique({
    where: { email: session.user.email }
  })

  if (!user) {
    return sendError(event, createError({ statusCode: 404, statusMessage: 'Пользователь не найден' }))
  }

  const journal = await prisma.journal.create({
    data: {
      character,
      content,
      image,
      userId: user.id
    }
  })

  return journal
})
