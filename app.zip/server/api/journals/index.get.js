import { getServerSession } from '#auth'
import { prisma } from '#nuxt-prisma'

export default defineEventHandler(async (event) => {
  const session = await getServerSession(event)

  if (!session?.user?.email) {
    return sendError(event, createError({ statusCode: 401, statusMessage: 'Не авторизован' }))
  }

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
    include: {
      journals: {
        orderBy: {
          updatedAt: 'desc'
        }
      }
    }
  })

  if (!user) {
    return sendError(event, createError({ statusCode: 404, statusMessage: 'Пользователь не найден' }))
  }

  return user.journals
})
