import { prisma } from '~/server/db/client'

export default defineEventHandler(async (event) => {
  const { journalSlug, postSlug } = event.context.params

  const journal = await prisma.journal.findUnique({
    where: { slug: journalSlug },
  })

  if (!journal) {
    return sendError(event, createError({ statusCode: 404, statusMessage: 'Journal not found' }))
  }

  const post = await prisma.journalPost.findFirst({
    where: {
      slug: postSlug,
      journalId: journal.id,
    },
  })

  if (!post) {
    return sendError(event, createError({ statusCode: 404, statusMessage: 'Post not found' }))
  }

  return post
})
