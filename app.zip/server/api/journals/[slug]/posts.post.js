import { prisma } from '~/server/db/client'
import { getServerSession } from '#auth'

export default defineEventHandler(async (event) => {
  const slug = event.context.params.slug
  const body = await readBody(event)
  const session = await getServerSession(event)

  if (!session?.user?.email) {
    return sendError(event, createError({ statusCode: 401, statusMessage: 'Unauthorized' }))
  }

  const journal = await prisma.journal.findUnique({
    where: { slug },
  })

  if (!journal) {
    return sendError(event, createError({ statusCode: 404, statusMessage: 'Journal not found' }))
  }

  // Проверяем, что пользователь владеет дневником
  const user = await prisma.user.findUnique({
    where: { email: session.user.email }
  })

  if (journal.userId !== user.id) {
    return sendError(event, createError({ statusCode: 403, statusMessage: 'Forbidden' }))
  }

  const { title, content, image } = body

  if (!title || !content) {
    return sendError(event, createError({ statusCode: 400, statusMessage: 'Title and content are required' }))
  }

  const post = await prisma.journalPost.create({
    data: {
      title,
      content,
      image,
      journalId: journal.id,
    }
  })

  return post
})
