import { prisma } from '~/server/db/client'

export default defineEventHandler(async (event) => {
  const slug = event.context.params.slug

  if (!slug) {
    return sendError(event, createError({ statusCode: 400, statusMessage: 'Slug is required' }))
  }

  const journal = await prisma.journal.findUnique({
    where: { slug },
    include: {
      posts: {
        orderBy: { createdAt: 'desc' }
      }
    }
  })

  if (!journal) {
    return sendError(event, createError({ statusCode: 404, statusMessage: 'Journal not found' }))
  }

  return journal.posts
})
